package com.example.armeasure

import com.google.ar.core.Pose
import kotlin.math.sqrt

data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun minus(o: Vec3) = Vec3(x-o.x, y-o.y, z-o.z)
    operator fun plus(o: Vec3) = Vec3(x+o.x, y+o.y, z+o.z)
    operator fun times(k: Double) = Vec3(x*k, y*k, z*k)
    fun dot(o: Vec3) = x*o.x + y*o.y + z*o.z
    fun cross(o: Vec3) = Vec3(y*o.z-z*o.y, z*o.x-x*o.z, x*o.y-y*o.x)
    fun length() = sqrt(x*x + y*y + z*z)
    companion object {
        fun fromPose(p: Pose): Vec3 {
            val t = p.translation
            return Vec3(t[0].toDouble(), t[1].toDouble(), t[2].toDouble())
        }
    }
}

object Geometry {
    fun distance(a: Vec3, b: Vec3, scale: Double = 1.0) = (a-b).length() * scale

    /** 3D polygon area using the magnitude of the vector area sum. Polygon must be ordered. */
    fun polygonArea(points: List<Vec3>, scale: Double = 1.0): Double {
        if (points.size < 3) return 0.0
        var sum = Vec3(0.0, 0.0, 0.0)
        for (i in points.indices) {
            sum += points[i].cross(points[(i + 1) % points.size])
        }
        return 0.5 * sum.length() * scale * scale
    }

    fun perimeter(points: List<Vec3>, scale: Double = 1.0): Double {
        if (points.size < 2) return 0.0
        var total = 0.0
        for (i in points.indices) total += distance(points[i], points[(i+1) % points.size], scale)
        return total
    }

    fun rectangularVolume(length: Double, width: Double, height: Double) =
        length * width * height

    fun calibratedScale(referenceMeters: Double, measuredMeters: Double): Double {
        require(referenceMeters > 0 && measuredMeters > 0)
        return referenceMeters / measuredMeters
    }

    fun formatMeters(m: Double, unit: String): String = when(unit) {
        "mm" -> "%.1f mm".format(m * 1000.0)
        "cm" -> "%.2f cm".format(m * 100.0)
        else -> "%.3f m".format(m)
    }
}
