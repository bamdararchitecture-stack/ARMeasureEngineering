package com.example.armeasure

import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.google.ar.core.Frame
import com.google.ar.core.HitResult
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Minimal ARCore renderer:
 * - camera background through external OES texture
 * - screen-center plane/depth hit test on user request
 * - anchor positions retained in AR world coordinates
 *
 * Rendering of dimension labels/line overlays is intentionally kept lightweight in this starter.
 */
class ArRenderer(
    private val activity: MainActivity,
    private val session: Session,
    private val onMeasure: (Int, Double) -> Unit
) : GLSurfaceView.Renderer {
    private var textureId = -1
    private var frame: Frame? = null
    private val pendingPoint = AtomicBoolean(false)
    private val anchors = mutableListOf<com.google.ar.core.Anchor>()
    private var lastSegment = 0.0
    @Volatile private var viewWidth = 1
    @Volatile private var viewHeight = 1
    private var cameraProgram = 0
    private var positionBuffer: FloatBuffer? = null
    private var texBuffer: FloatBuffer? = null
    private val quad = floatArrayOf(-1f,-1f, 1f,-1f, -1f,1f, 1f,1f)
    private val uv = floatArrayOf(0f,1f, 1f,1f, 0f,0f, 1f,0f)
    private val transformedUv = FloatArray(8)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        textureId = IntArray(1).also { GLES20.glGenTextures(1,it,0) }[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        session.setCameraTextureNames(intArrayOf(textureId))
        cameraProgram = createProgram(VS, FS)
        positionBuffer = buffer(quad)
        texBuffer = buffer(uv)
        GLES20.glClearColor(0f,0f,0f,1f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewWidth = width
        viewHeight = height
        GLES20.glViewport(0,0,width,height)
        session.setDisplayGeometry(activity.windowManager.defaultDisplay.rotation,width,height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        try {
            val f = session.update()
            frame = f
            drawCamera(f)
            if (f.camera.trackingState != TrackingState.TRACKING) return
            if (pendingPoint.compareAndSet(true,false)) {
                // ARCore hitTest expects pixel coordinates, not normalized 0..1 coordinates.
                val hits = f.hitTest(viewWidth * 0.5f, viewHeight * 0.5f)
                val hit = hits.firstOrNull { h ->
                    val t = h.trackable
                    (t is com.google.ar.core.Plane && t.isPoseInPolygon(h.hitPose)) ||
                        t is com.google.ar.core.Point
                }
                if (hit != null) addHit(hit)
            }
        } catch (_: Exception) { /* Session may be paused during lifecycle changes. */ }
    }

    private fun drawCamera(f: Frame) {
        f.transformCoordinates2d(
            com.google.ar.core.Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES,
            quad,
            com.google.ar.core.Coordinates2d.TEXTURE_NORMALIZED,
            transformedUv
        )
        val p = cameraProgram
        GLES20.glUseProgram(p)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(p,"uTexture"),0)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0,2,GLES20.GL_FLOAT,false,0,positionBuffer)
        GLES20.glEnableVertexAttribArray(1)
        GLES20.glVertexAttribPointer(1,2,GLES20.GL_FLOAT,false,0,buffer(transformedUv))
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
        GLES20.glDisableVertexAttribArray(0); GLES20.glDisableVertexAttribArray(1)
    }

    @Synchronized private fun addHit(hit: HitResult) {
        val anchor = hit.createAnchor()
        anchors.add(anchor)
        if (anchors.size >= 2) {
            val a = Vec3.fromPose(anchors[anchors.lastIndex-1].pose)
            val b = Vec3.fromPose(anchors.last().pose)
            lastSegment = Geometry.distance(a,b)
        }
        val count = anchors.size
        onMeasure(count,lastSegment)
    }

    fun requestPoint() { pendingPoint.set(true) }
    @Synchronized fun undoPoint() {
        if (anchors.isNotEmpty()) anchors.removeAt(anchors.lastIndex).detach()
        lastSegment = if (anchors.size >= 2) Geometry.distance(
            Vec3.fromPose(anchors[anchors.lastIndex-1].pose),
            Vec3.fromPose(anchors.last().pose)) else 0.0
        onMeasure(anchors.size,lastSegment)
    }
    @Synchronized fun clearPoints() { anchors.forEach { it.detach() }; anchors.clear(); lastSegment=0.0; onMeasure(0,0.0) }
    @Synchronized fun lastSegmentMeters() = lastSegment
    fun refreshStatus() { onMeasure(anchors.size,lastSegment) }

    private fun buffer(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(a).apply { position(0) }

    private fun createProgram(vs: String, fs: String): Int {
        fun shader(type:Int, src:String):Int {
            val s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,src); GLES20.glCompileShader(s); return s
        }
        val p=GLES20.glCreateProgram()
        GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,vs))
        GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,fs))
        GLES20.glBindAttribLocation(p,0,"aPosition"); GLES20.glBindAttribLocation(p,1,"aTexCoord")
        GLES20.glLinkProgram(p); return p
    }

    companion object {
        private const val VS = "attribute vec4 aPosition; attribute vec2 aTexCoord; varying vec2 vTexCoord; void main(){gl_Position=aPosition; vTexCoord=aTexCoord;}"
        private const val FS = "#extension GL_OES_EGL_image_external : require\nprecision mediump float; varying vec2 vTexCoord; uniform samplerExternalOES uTexture; void main(){gl_FragColor=texture2D(uTexture,vTexCoord);}"
    }
}
