package com.example.armeasure

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var renderer: ArRenderer
    private lateinit var status: TextView
    private var session: Session? = null
    private var unit = "m"
    private var calibration = 1.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)
        } else setup()
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if (r == 10 && g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) setup()
        else showMessage("برای اندازه‌گیری، اجازه دسترسی به دوربین لازم است.")
    }

    private fun setup() {
        try {
            val availability = ArCoreApk.getInstance().checkAvailability(this)
            if (availability.isTransient) {
                showMessage("در حال بررسی سازگاری ARCore؛ برنامه را دوباره باز کنید.")
                return
            }
            if (!availability.isSupported) {
                showMessage("این گوشی در حال حاضر توسط ARCore پشتیبانی نمی‌شود. حالت اندازه‌گیری AR قابل اجرا نیست.")
                return
            }
            session = Session(this).also {
                val config = Config(it)
                config.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                config.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                config.depthMode = if (it.isDepthModeSupported(Config.DepthMode.AUTOMATIC))
                    Config.DepthMode.AUTOMATIC else Config.DepthMode.DISABLED
                it.configure(config)
            }
        } catch (e: Exception) {
            showMessage("راه‌اندازی ARCore ناموفق بود: ${e.localizedMessage ?: "خطای ناشناخته"}")
            return
        }

        gl = GLSurfaceView(this).apply {
            preserveEGLContextOnPause = true
            setEGLContextClientVersion(2)
            renderer = ArRenderer(this@MainActivity, session!!) { count, length ->
                runOnUiThread { status.text = "نقاط: $count   |   فاصله آخر: ${Geometry.formatMeters(length * calibration, unit)}" }
            }
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(0xCC101820.toInt())
        }
        status = TextView(this).apply {
            text = "دوربین را آرام حرکت دهید تا سطوح شناسایی شوند."
            setTextColor(0xFFFFFFFF.toInt()); textSize = 14f
        }
        panel.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(makeButton("ثبت نقطه") { renderer.requestPoint() })
        row.addView(makeButton("بازگشت") { renderer.undoPoint() })
        row.addView(makeButton("کالیبراسیون") { calibrate() })
        panel.addView(row)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(makeButton("واحد") { unit = when(unit) { "m" -> "cm"; "cm" -> "mm"; else -> "m" }; renderer.refreshStatus() })
        row2.addView(makeButton("پاک‌کردن") { renderer.clearPoints() })
        panel.addView(row2)

        val root = android.widget.FrameLayout(this)
        root.addView(gl)
        root.addView(panel, android.widget.FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; setOnClickListener { action() }
    }

    private fun calibrate() {
        val input = EditText(this).apply { hint = "طول واقعی بر حسب متر، مثال 1.000"; inputType = 8194 }
        AlertDialog.Builder(this).setTitle("کالیبراسیون با طول مرجع")
            .setMessage("دو نقطه مرجع را با «ثبت نقطه» انتخاب کنید. سپس طول واقعی فاصله بین آن‌ها را وارد کنید.")
            .setView(input)
            .setPositiveButton("اعمال") { _, _ ->
                val known = input.text.toString().toDoubleOrNull()
                val measured = renderer.lastSegmentMeters()
                if (known != null && known > 0 && measured > 0) {
                    calibration = Geometry.calibratedScale(known, measured)
                    renderer.refreshStatus()
                    showMessage("ضریب کالیبراسیون اعمال شد: %.5f".format(Locale.US, calibration))
                } else showMessage("ابتدا دو نقطه ثبت کنید و طول معتبر وارد کنید.")
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showMessage(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onResume() { super.onResume(); if (::gl.isInitialized) { session?.resume(); gl.onResume() } }
    override fun onPause() { if (::gl.isInitialized) { gl.onPause(); session?.pause() }; super.onPause() }
    override fun onDestroy() { session?.close(); super.onDestroy() }
}
